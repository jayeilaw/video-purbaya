import type {FC, ReactNode} from 'react';
import {AbsoluteFill, Audio, Easing, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {COL, GEAR_A, GEAR_B, H, HEART, STAR, W, bitRows, spriteRects, textLayout} from './art';

// ---------- alat bantu ----------
const clampOpt = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ip = (f: number, i: number[], o: number[], easing?: (t: number) => number) =>
  interpolate(f, i, o, {...clampOpt, easing});
const hopY = (f: number, s: number, h = 8, d = 14) => {
  if (f < s || f > s + d) return 0;
  const t = (f - s) / d;
  return -Math.round(4 * h * t * (1 - t));
};
const popS = (f: number, s: number) => (f < s ? 0 : ip(f - s, [0, 4, 8], [0, 1.3, 1]));
const typed = (f: number, start: number, len: number, speed = 1) =>
  Math.max(0, Math.min(len, Math.floor((f - start) * speed) + 1));

let seed = 7;
const rnd = () => {
  seed = (seed * 16807) % 2147483647;
  return seed / 2147483647;
};
const STARS = Array.from({length: 42}, () => ({x: Math.floor(rnd() * W), y: Math.floor(rnd() * 58), t: Math.floor(rnd() * 60)}));
const CONF = Array.from({length: 30}, (_, i) => ({
  vx: (rnd() - 0.5) * 4.4, vy: -1 - rnd() * 2.6, c: [COL.cyan, COL.amber, COL.pink, COL.green, COL.violet][i % 5],
}));
const RANK = (() => {
  const a = Array.from({length: 144}, (_, i) => i);
  let s = 11;
  for (let i = a.length - 1; i > 0; i -= 1) {
    s = (s * 16807) % 2147483647;
    const j = s % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
})();

// ---------- primitif gambar ----------
const Canvas: FC<{children: ReactNode}> = ({children}) => (
  <AbsoluteFill>
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%" shapeRendering="crispEdges" style={{display: 'block'}}>
      {children}
    </svg>
  </AbsoluteFill>
);

const R: FC<{x: number; y: number; w: number; h: number; c: string; o?: number}> = ({x, y, w, h, c, o}) => (
  <rect x={x} y={y} width={w} height={h} fill={c} opacity={o} />
);

const Sprite: FC<{rows: string[]; x: number; y: number; o?: number}> = ({rows, x, y, o = 1}) => (
  <g transform={`translate(${Math.round(x)} ${Math.round(y)})`} opacity={o}>
    {spriteRects(rows).map((r, i) => <rect key={i} x={r.x} y={r.y} width={r.w} height={r.h} fill={r.c} />)}
  </g>
);

const Txt: FC<{s: string; x: number; y: number; scale?: number; c?: string; a?: 'l' | 'c' | 'r'; sh?: string; n?: number; o?: number}> =
  ({s, x, y, scale = 1, c = COL.white, a = 'l', sh, n, o = 1}) => {
    const {rects, width} = textLayout(s, scale, n ?? s.length);
    const ox = Math.round(a === 'c' ? x - width / 2 : a === 'r' ? x - width : x);
    const oy = Math.round(y);
    return (
      <g opacity={o}>
        {sh && (
          <g transform={`translate(${ox + scale} ${oy + scale})`}>
            {rects.map((r, i) => <rect key={i} x={r.x} y={r.y} width={r.w} height={r.h} fill={sh} />)}
          </g>
        )}
        <g transform={`translate(${ox} ${oy})`}>
          {rects.map((r, i) => <rect key={i} x={r.x} y={r.y} width={r.w} height={r.h} fill={c} />)}
        </g>
      </g>
    );
  };

const Tile: FC<{x: number; y: number; t: string; c?: string; fg?: string; w?: number; h?: number; s?: number; ring?: string}> =
  ({x, y, t, c = COL.amber, fg = COL.ink, w = 9, h = 9, s = 1, ring}) => {
    if (s <= 0) return null;
    const tw = textLayout(t, 1, t.length).width;
    const cx = x + w / 2;
    const cy = y + h / 2;
    return (
      <g transform={`translate(${cx} ${cy}) scale(${s}) translate(${-cx} ${-cy})`}>
        <R x={x} y={y} w={w} h={h} c={c} />
        <R x={x} y={y} w={w} h={1} c="#FFFFFF" o={0.35} />
        <R x={x} y={y + h - 1} w={w} h={1} c="#000000" o={0.25} />
        {ring && <rect x={x - 0.5} y={y - 0.5} width={w + 1} height={h + 1} fill="none" stroke={ring} strokeWidth={1} />}
        <Txt s={t} x={x + (w - tw) / 2} y={y + (h - 5) / 2} c={fg} />
      </g>
    );
  };

const Bubble: FC<{x: number; y: number; t: string}> = ({x, y, t}) => {
  const w = textLayout(t, 1, t.length).width + 6;
  return (
    <g>
      <R x={x} y={y} w={w} h={9} c="#FFFFFF" />
      <R x={x + 2} y={y + 9} w={2} h={1} c="#FFFFFF" />
      <R x={x} y={y + 10} w={2} h={1} c="#FFFFFF" />
      <Txt s={t} x={x + 3} y={y + 2} c={COL.ink} />
    </g>
  );
};

const Label: FC<{s: string; c: string; f: number}> = ({s, c, f}) => {
  const n = typed(f, 0, s.length, 0.5);
  return (
    <g>
      <Txt s={s} x={6} y={5} c={c} sh="#000000" n={n} />
      <R x={6} y={12} w={Math.min(textLayout(s, 1, s.length).width, n * 4)} h={1} c={c} />
    </g>
  );
};

// ---------- latar, maskot, dekorasi ----------
const Backdrop: FC<{f: number; accent: string}> = ({f, accent}) => {
  const s = Math.floor(f * 0.3);
  const shift = Math.floor(s / 10);
  return (
    <g>
      <R x={0} y={0} w={W} h={H} c={COL.bg} />
      {STARS.map((st, i) => <R key={i} x={st.x} y={st.y} w={1} h={1} c={COL.star} o={(f + st.t) % 60 < 48 ? 0.9 : 0.3} />)}
      {[0, 1, 2, 3, 4, 5, 6].map((r) => (
        <line key={r} x1={0} x2={W} y1={62.5 + r} y2={62.5 + r} stroke={accent} strokeWidth={1}
          strokeDasharray="1 1" strokeDashoffset={r % 2} opacity={0.1 + 0.012 * r} />
      ))}
      <R x={0} y={69} w={W} h={1} c={accent} />
      {[0, 1, 2, 3].map((r) => Array.from({length: 17}, (_, c) => (
        <R key={`${r}-${c}`} x={c * 10 - (s % 10)} y={70 + r * 5} w={10} h={5} c={(c + shift + r) % 2 === 0 ? COL.floorA : COL.floorB} />
      )))}
    </g>
  );
};

const Floaters: FC<{f: number; c: string}> = ({f, c}) => (
  <g>
    {Array.from({length: 10}, (_, i) => (
      <Txt key={i} s={i % 2 ? '1' : '0'} x={6 + i * 16 + (i % 3) * 3} y={Math.round(64 - ((f * 0.35 + i * 21) % 60))} c={c} o={0.28} />
    ))}
  </g>
);

const Bit: FC<{x: number; f: number; g?: number; walk?: boolean; happy?: boolean; up?: number}> =
  ({x, f, g = 68, walk = false, happy = false, up = 0}) => {
    const blink = f % 96 < 4 && !happy;
    const step = Math.floor(f / 5) % 2;
    const feet = up < -1 ? 'jump' : walk ? (step ? 'a' : 'b') : 'idle';
    const bob = walk && step ? -1 : 0;
    const rows = bitRows(blink ? 'blink' : 'open', happy || up < -1 ? 'open' : 'smile', feet);
    return (
      <g>
        <R x={Math.round(x) + 1} y={g} w={10} h={1} c="#000000" o={0.35} />
        <Sprite rows={rows} x={x} y={g - 13 + bob + up} />
      </g>
    );
  };

const Confetti: FC<{f: number; t0: number; x0: number; y0: number}> = ({f, t0, x0, y0}) => {
  const t = f - t0;
  if (t < 0) return null;
  return (
    <g>
      {CONF.map((p, i) => {
        const x = x0 + p.vx * t;
        const y = y0 + p.vy * t + 0.06 * t * t;
        if (y > 88 || x < 0 || x > W) return null;
        return <R key={i} x={Math.round(x)} y={Math.round(y)} w={2} h={2} c={p.c} />;
      })}
    </g>
  );
};

// ---------- perangkat ----------
const Keyboard: FC<{x: number; y: number; pressed: number}> = ({x, y, pressed}) => {
  const keys: number[][] = [];
  [2, 6, 10, 14, 18, 22, 26].forEach((kx) => keys.push([kx, 2]));
  [3, 7, 11, 15, 19, 23].forEach((kx) => keys.push([kx, 5]));
  return (
    <g transform={`translate(${x} ${y})`}>
      <R x={0} y={0} w={30} h={10} c={COL.dgray} />
      <R x={1} y={1} w={28} h={8} c={COL.mgray} />
      {keys.map((k, i) => <R key={i} x={k[0]} y={k[1] + (i === pressed ? 1 : 0)} w={3} h={2} c={i === pressed ? COL.amber : COL.lgray} />)}
      <R x={8} y={8} w={14} h={1} c={COL.lgray} />
    </g>
  );
};

const Mouse: FC<{x: number; y: number; click: boolean}> = ({x, y, click}) => (
  <g>
    <R x={x + 3} y={y - 5} w={1} h={5} c={COL.dgray} />
    <R x={x} y={y} w={7} h={9} c={COL.lgray} />
    <R x={x} y={y + 8} w={7} h={1} c={COL.gray} />
    <R x={x + 3} y={y} w={1} h={4} c={COL.gray} />
    {click && <R x={x + 1} y={y} w={2} h={4} c={COL.amber} />}
  </g>
);

const Chip: FC<{x: number; y: number; f: number; busy: boolean; dy: number}> = ({x, y: y0, f, busy, dy}) => {
  const y = y0 + dy;
  const pupil = busy ? Math.floor(f / 4) % 2 : 1;
  const open = busy && Math.floor(f / 3) % 2 === 0;
  const led = busy && Math.floor(f / 4) % 2 === 0 ? COL.green : COL.amber;
  return (
    <g>
      <R x={x + 2} y={y + 2} w={14} h={14} c="#4B5563" />
      <R x={x + 3} y={y + 3} w={12} h={12} c="#1F2937" />
      {[0, 1, 2, 3].map((i) => (
        <g key={i}>
          <R x={x} y={y + 3 + i * 3} w={2} h={1} c={COL.amber} />
          <R x={x + 16} y={y + 3 + i * 3} w={2} h={1} c={COL.amber} />
          <R x={x + 4 + i * 3} y={y} w={1} h={2} c={COL.amber} />
          <R x={x + 4 + i * 3} y={y + 16} w={1} h={2} c={COL.amber} />
        </g>
      ))}
      <R x={x + 5} y={y + 6} w={3} h={3} c="#FFFFFF" />
      <R x={x + 10} y={y + 6} w={3} h={3} c="#FFFFFF" />
      <R x={x + 6 + pupil} y={y + 7} w={1} h={1} c={COL.ink} />
      <R x={x + 11 + pupil} y={y + 7} w={1} h={1} c={COL.ink} />
      <R x={x + 7} y={y + 11} w={4} h={open ? 2 : 1} c={open ? COL.pink : COL.amber} />
      <R x={x + 4} y={y + 4} w={1} h={1} c={led} />
    </g>
  );
};

const Monitor: FC<{x: number; y: number; on: boolean; bars: number[]}> = ({x, y, on, bars}) => (
  <g>
    <R x={x} y={y} w={32} h={20} c={COL.lgray} />
    <R x={x + 2} y={y + 2} w={28} h={16} c={on ? '#10224A' : COL.ink} />
    {on && bars.map((h, k) => (
      <R key={k} x={x + 3 + k * 7} y={y + 17 - h} w={5} h={h} c={[COL.cyan, COL.green, COL.amber, COL.pink][k]} />
    ))}
    <R x={x + 14} y={y + 20} w={4} h={3} c={COL.gray} />
    <R x={x + 8} y={y + 23} w={16} h={3} c={COL.gray} />
  </g>
);

const Floppy: FC<{x: number; y: number; flash: boolean}> = ({x, y, flash}) => (
  <g>
    <R x={x} y={y} w={14} h={14} c={flash ? '#FFFFFF' : COL.violet} />
    <R x={x + 3} y={y} w={8} h={5} c={COL.lgray} />
    <R x={x + 8} y={y + 1} w={2} h={3} c={COL.ink} />
    <R x={x + 2} y={y + 8} w={10} h={6} c="#FFFFFF" />
    <R x={x + 3} y={y + 10} w={8} h={1} c={COL.gray} />
    <R x={x + 3} y={y + 12} w={5} h={1} c={COL.gray} />
  </g>
);

// ---------- adegan ----------
const SceneTitle: FC = () => {
  const f = useCurrentFrame();
  const up = f < 22 ? Math.round(ip(f, [0, 22], [-70, 0], Easing.in(Easing.quad))) : hopY(f, 22, 6, 16) + hopY(f, 38, 3, 10);
  const x = f < 85 ? 74 : Math.round(74 + (f - 85) * 4);
  return (
    <Canvas>
      <Backdrop f={f} accent={COL.cyan} />
      <Floaters f={f} c={COL.cyan} />
      <Txt s="PERJALANAN DATA" x={80} y={12} scale={2} c={COL.amber} sh="#000000" a="c" n={typed(f, 28, 15, 0.5)} />
      {f >= 62 && <Txt s="REPRESENTASI DAN PEMROSESAN DATA" x={80} y={28} sh="#000000" a="c" n={typed(f, 62, 32, 1.5)} />}
      {f >= 44 && f < 84 && <Bubble x={88} y={43} t="HALO!" />}
      <Bit x={x} f={f} walk={f >= 85} up={up} happy={f >= 44 && f < 85} />
    </Canvas>
  );
};

const SceneRep: FC = () => {
  const f = useCurrentFrame();
  const bx = f < 35 ? Math.round(ip(f, [0, 35], [-14, 74], Easing.out(Easing.quad))) : 74;
  const bits = '01000001'.split('');
  const up = hopY(f, 135) + hopY(f, 160);
  return (
    <Canvas>
      <Backdrop f={f} accent={COL.cyan} />
      <Floaters f={f} c={COL.cyan} />
      <Label s="REPRESENTASI DATA" c={COL.cyan} f={f} />
      <Tile x={14} y={26} t="A" s={popS(f, 38)} />
      {f >= 48 && <Txt s="=" x={26} y={28} c={COL.amber} />}
      <Tile x={32} y={26} w={11} t="65" s={popS(f, 54)} />
      {f >= 64 && <Txt s="=" x={46} y={28} c={COL.amber} />}
      {bits.map((b, i) => (
        <Tile key={i} x={54 + i * 11} y={26} t={b} s={popS(f, 72 + i * 7)}
          c={b === '1' ? COL.cyan : '#16213E'} fg={b === '1' ? COL.ink : COL.cyan} ring={b === '1' ? undefined : COL.cyan} />
      ))}
      {f >= 130 && <Txt s="KOMPUTER HANYA PAHAM 0 DAN 1" x={80} y={40} sh="#000000" a="c" n={typed(f, 130, 28, 1.2)} />}
      <Bit x={bx} f={f} walk={f < 35} up={up} happy={f >= 120} />
    </Canvas>
  );
};

const KEY_EVENTS = [45, 55, 65, 75];
const KEY_IDS = [3, 1, 9, 1];

const SceneInput: FC = () => {
  const f = useCurrentFrame();
  const bx = f < 28 ? Math.round(ip(f, [0, 28], [-14, 30], Easing.out(Easing.quad))) : f >= 128 ? Math.round(30 + (f - 128) * 4) : 30;
  const count = KEY_EVENTS.filter((e) => f >= e).length;
  const pressedAt = KEY_EVENTS.findIndex((e) => f >= e && f < e + 4);
  const sent = f >= 88;
  const word = 'DATA'.slice(0, count);
  const wordW = textLayout('DATA', 2, 4).width;
  const curX = 80 - wordW / 2 + (word ? textLayout(word, 2, word.length).width + 2 : 0);
  const up = hopY(f, 100) + hopY(f, 118);
  return (
    <Canvas>
      <Backdrop f={f} accent={COL.violet} />
      <Label s="TAHAP 1: INPUT" c={COL.violet} f={f} />
      {f >= 30 && (
        <g>
          <R x={48} y={26} w={64} h={16} c="#16213E" />
          <rect x={48.5} y={26.5} width={63} height={15} fill="none" stroke={sent && f < 92 ? '#FFFFFF' : COL.violet} strokeWidth={1} />
          <Txt s={word} x={80 - wordW / 2} y={29} scale={2} c={sent ? COL.green : COL.white} />
          {!sent && Math.floor(f / 8) % 2 === 0 && <R x={Math.round(curX)} y={29} w={2} h={10} c={COL.violet} />}
        </g>
      )}
      <Keyboard x={60} y={58} pressed={pressedAt >= 0 ? KEY_IDS[pressedAt] : -1} />
      <Mouse x={100} y={59} click={f >= 86 && f < 92} />
      {f >= 96 && <Txt s="DATA MASUK KE KOMPUTER" x={80} y={76} sh="#000000" a="c" n={typed(f, 96, 22, 1.2)} />}
      <Bit x={bx} f={f} walk={f < 28 || f >= 128} up={up} happy={f >= 88} />
    </Canvas>
  );
};

const IN_VALUES = ['7', '3', '9', '2'];
const OPS = [[44, 'HITUNG'], [64, 'BANDING'], [84, 'URUTKAN'], [104, 'KELOMPOKKAN']] as const;
const OUT_ORDER = [['9', 142], ['7', 130], ['3', 118], ['2', 106]] as const;
const SORTED = ['2', '3', '7', '9'];

const SceneProses: FC = () => {
  const f = useCurrentFrame();
  const bx = f < 22 ? Math.round(ip(f, [0, 22], [-14, 14], Easing.out(Easing.quad))) : f >= 160 ? Math.round(14 + (f - 160) * 4) : 14;
  const busy = f >= 41 && f < 136;
  const munch = IN_VALUES.some((_, i) => f >= 14 + 9 * i + 27 && f < 14 + 9 * i + 29);
  const op = OPS.filter((o) => f >= o[0] && f < o[0] + 20)[0];
  const up = hopY(f, 142) + hopY(f, 158);
  const shake = busy ? (Math.floor(f / 2) % 2 === 0 ? -1 : 0) : 0;
  return (
    <Canvas>
      <Backdrop f={f} accent={COL.amber} />
      <Label s="TAHAP 2: PROSES" c={COL.amber} f={f} />
      <R x={34} y={58} w={116} h={3} c={COL.dgray} />
      {Array.from({length: 14}, (_, k) => <R key={k} x={34 + ((k * 8 + Math.floor(f * 1.6)) % 116)} y={59} w={2} h={1} c={COL.mgray} />)}
      {IN_VALUES.map((v, i) => {
        const s = 14 + 9 * i;
        const x = 34 + 1.6 * (f - s);
        return f >= s && x < 77 ? <Tile key={i} x={Math.round(x)} y={50} w={8} h={8} t={v} /> : null;
      })}
      <Chip x={83 + shake} y={40} f={f} busy={busy} dy={munch ? 1 : 0} />
      {busy && <Sprite rows={Math.floor(f / 4) % 2 ? GEAR_A : GEAR_B} x={104} y={34} />}
      {op && (
        <g>
          <Bubble x={Math.round(92 - (textLayout(op[1], 1, op[1].length).width + 6) / 2)} y={22} t={op[1]} />
        </g>
      )}
      {OUT_ORDER.map((o, k) => {
        const e = 108 + 8 * k;
        const x = Math.min(o[1], 101 + 1.6 * (f - e));
        const j = SORTED.indexOf(o[0]);
        const flash = f >= 140 + 6 * j && f < 146 + 6 * j;
        return f >= e ? <Tile key={k} x={Math.round(x)} y={50} w={8} h={8} t={o[0]} c={COL.amber} ring={flash ? '#FFFFFF' : undefined} /> : null;
      })}
      {f >= 145 && <Txt s="HASIL: DATA TERURUT" x={80} y={76} sh="#000000" a="c" n={typed(f, 145, 19, 1.2)} />}
      <Bit x={bx} f={f} walk={f < 22 || f >= 160} up={up} happy={f >= 140} />
    </Canvas>
  );
};

const SceneOutput: FC = () => {
  const f = useCurrentFrame();
  const bx = f < 20 ? Math.round(ip(f, [0, 20], [-14, 24], Easing.out(Easing.quad))) : f >= 115 ? Math.round(24 + (f - 115) * 4) : 24;
  const bars = [4, 7, 10, 13].map((h, k) => Math.round(ip(f - (34 + 10 * k), [0, 8], [0, h])));
  const paper = Math.round(ip(f, [88, 110], [0, 9]));
  const up = hopY(f, 80) + hopY(f, 100);
  return (
    <Canvas>
      <Backdrop f={f} accent={COL.green} />
      <Label s="TAHAP 3: OUTPUT" c={COL.green} f={f} />
      <R x={40} y={58} w={100} h={3} c="#4B5563" />
      <R x={44} y={61} w={2} h={9} c="#4B5563" />
      <R x={134} y={61} w={2} h={9} c="#4B5563" />
      <Monitor x={64} y={32} on={f >= 20} bars={f >= 20 ? bars : [0, 0, 0, 0]} />
      {f >= 20 && f < 24 && <R x={66} y={34} w={28} h={16} c="#FFFFFF" o={0.8} />}
      <R x={102} y={50} w={14} h={8} c={COL.lgray} />
      <R x={104} y={51} w={10} h={1} c={COL.dgray} />
      {paper > 0 && (
        <g>
          <R x={105} y={50 - paper} w={8} h={paper} c="#FFFFFF" />
          {paper >= 6 && <R x={106} y={50 - paper + 2} w={6} h={1} c={COL.cyan} />}
          {paper >= 8 && <R x={106} y={50 - paper + 4} w={4} h={1} c={COL.cyan} />}
        </g>
      )}
      <R x={122} y={44} w={10} h={14} c={COL.dgray} />
      <R x={123} y={45} w={8} h={12} c="#1F2937" />
      <R x={125} y={50} w={4} h={4} c={COL.gray} />
      <R x={126} y={51} w={2} h={2} c={COL.lgray} />
      <R x={126} y={47} w={2} h={2} c={COL.gray} />
      {f >= 78 && [0, 1, 2].map((k) => (Math.floor(f / 4) + k) % 3 !== 0 ? <R key={k} x={134 + k * 3} y={51 - Math.floor((3 + 2 * k) / 2)} w={1} h={3 + 2 * k} c={COL.green} /> : null)}
      {f >= 78 && <Txt s="INFORMASI!" x={80} y={14} scale={2} c={COL.green} sh="#000000" a="c" n={typed(f, 78, 10, 1.5)} />}
      {f >= 92 && <Txt s="TAMPIL DI LAYAR, PRINTER, SPEAKER" x={80} y={76} sh="#000000" a="c" n={typed(f, 92, 33, 1.5)} />}
      <Confetti f={f} t0={78} x0={80} y0={30} />
      <Bit x={bx} f={f} walk={f < 20 || f >= 115} up={up} happy={f >= 78} />
    </Canvas>
  );
};

const SceneSimpan: FC = () => {
  const f = useCurrentFrame();
  const bx = f < 18 ? Math.round(ip(f, [0, 18], [-14, 40], Easing.out(Easing.quad))) : 40;
  const p = ip(f, [22, 34], [0, 1]);
  const sx = 43 + 33 * p;
  const sy = 44 - 6 + (36 - 44 + 6) * p - 8 * 4 * p * (1 - p) + 6 * p;
  const bob = Math.round(Math.sin(f / 6));
  const up = hopY(f, 22);
  return (
    <Canvas>
      <Backdrop f={f} accent={COL.pink} />
      <Label s="TAHAP 4: SIMPAN" c={COL.pink} f={f} />
      <Floppy x={73} y={34 + bob} flash={f >= 34 && f < 38} />
      {f < 34 && <Sprite rows={STAR} x={f < 22 ? bx + 3 : sx} y={f < 22 ? 44 : sy} />}
      {f >= 38 && <Txt s="TERSIMPAN!" x={80} y={14} scale={2} c={COL.pink} sh="#000000" a="c" n={typed(f, 38, 10, 1)} />}
      {f >= 42 && <Txt s="DATA DISIMPAN AGAR DAPAT DIPAKAI LAGI" x={80} y={76} sh="#000000" a="c" n={typed(f, 42, 37, 1.5)} />}
      <Bit x={bx} f={f} walk={f < 18} up={up} happy={f >= 22} />
    </Canvas>
  );
};

const SceneClose: FC = () => {
  const f = useCurrentFrame();
  const up = hopY(f, 10, 7) + hopY(f, 26, 7) + hopY(f, 42, 7);
  return (
    <Canvas>
      <Backdrop f={f} accent={COL.amber} />
      <Floaters f={f} c={COL.amber} />
      <Txt s="TERIMA KASIH" x={80} y={14} scale={2} c={COL.amber} sh="#000000" a="c" n={typed(f, 4, 12, 0.6)} />
      {f >= 30 && <Txt s="KELOMPOK 3 - PTI" x={80} y={32} sh="#000000" a="c" n={typed(f, 30, 16, 1)} />}
      {[8, 20, 136, 148].map((hx, i) => f >= 20 + 6 * i ? (
        <Sprite key={i} rows={HEART} x={hx + Math.round(Math.sin((f + i * 5) / 6) * 3)} y={Math.round(60 - (f - 20 - 6 * i) * 0.9)} />
      ) : null)}
      <Confetti f={f} t0={4} x0={80} y0={40} />
      <Bit x={74} f={f} up={up} happy />
      <R x={0} y={0} w={W} h={H} c="#000000" o={ip(f, [58, 70], [0, 1])} />
    </Canvas>
  );
};

const CUTS = [
  {at: 105, c: COL.cyan}, {at: 300, c: COL.violet}, {at: 465, c: COL.amber},
  {at: 645, c: COL.green}, {at: 780, c: COL.pink}, {at: 830, c: COL.amber},
];

const Transition: FC = () => {
  const f = useCurrentFrame();
  let p = 0;
  let c: string = COL.cyan;
  CUTS.forEach((k) => {
    if (f >= k.at - 9 && f <= k.at + 9) {
      p = f <= k.at ? (f - (k.at - 9)) / 9 : 1 - (f - k.at) / 9;
      c = k.c;
    }
  });
  if (p <= 0) return null;
  return (
    <Canvas>
      {RANK.map((r, i) => (r / 144 < p ? <R key={i} x={(i % 16) * 10} y={Math.floor(i / 16) * 10} w={10} h={10} c={c} /> : null))}
    </Canvas>
  );
};

export const BitVideo: FC = () => (
  <AbsoluteFill style={{backgroundColor: COL.bg}}>
    <Audio src={staticFile('bit-sfx.wav')} />
    <Sequence from={0} durationInFrames={105}><SceneTitle /></Sequence>
    <Sequence from={105} durationInFrames={195}><SceneRep /></Sequence>
    <Sequence from={300} durationInFrames={165}><SceneInput /></Sequence>
    <Sequence from={465} durationInFrames={180}><SceneProses /></Sequence>
    <Sequence from={645} durationInFrames={135}><SceneOutput /></Sequence>
    <Sequence from={780} durationInFrames={50}><SceneSimpan /></Sequence>
    <Sequence from={830} durationInFrames={70}><SceneClose /></Sequence>
    <Transition />
  </AbsoluteFill>
);
