// Data seni piksel: warna, font 3x5, dan sprite
export const W = 160;
export const H = 90;

export const COL = {
  bg: '#0B1020', floorA: '#141F42', floorB: '#0F1832', star: '#64748B',
  cyan: '#22D3EE', violet: '#A78BFA', amber: '#FBBF24', green: '#34D399', pink: '#FB7185',
  white: '#FFFFFF', ink: '#0B1020', gray: '#9CA3AF', dgray: '#374151', mgray: '#6B7280', lgray: '#E5E7EB',
};

export const PAL: Record<string, string> = {
  C: '#22D3EE', H: '#A5F3FC', D: '#0E7490', K: '#0B1020', W: '#FFFFFF', P: '#FB7185',
  G: '#CBD5E1', Y: '#FBBF24', y: '#FDE68A',
};

export const FONT: Record<string, string> = {
  A: '.#.|#.#|###|#.#|#.#', B: '##.|#.#|##.|#.#|##.', C: '.##|#..|#..|#..|.##',
  D: '##.|#.#|#.#|#.#|##.', E: '###|#..|##.|#..|###', F: '###|#..|##.|#..|#..',
  G: '.##|#..|#.#|#.#|.##', H: '#.#|#.#|###|#.#|#.#', I: '###|.#.|.#.|.#.|###',
  J: '..#|..#|..#|#.#|.#.', K: '#.#|#.#|##.|#.#|#.#', L: '#..|#..|#..|#..|###',
  M: '#...#|##.##|#.#.#|#...#|#...#', N: '#..#|##.#|#.##|#..#|#..#', O: '.#.|#.#|#.#|#.#|.#.',
  P: '##.|#.#|##.|#..|#..', Q: '.#.|#.#|#.#|##.|.##', R: '##.|#.#|##.|#.#|#.#',
  S: '.##|#..|.#.|..#|##.', T: '###|.#.|.#.|.#.|.#.', U: '#.#|#.#|#.#|#.#|###',
  V: '#.#|#.#|#.#|#.#|.#.', W: '#...#|#...#|#.#.#|##.##|#...#', X: '#.#|#.#|.#.|#.#|#.#',
  Y: '#.#|#.#|.#.|.#.|.#.', Z: '###|..#|.#.|#..|###',
  '0': '###|#.#|#.#|#.#|###', '1': '.#.|##.|.#.|.#.|###', '2': '##.|..#|.#.|#..|###',
  '3': '##.|..#|.#.|..#|##.', '4': '#.#|#.#|###|..#|..#', '5': '###|#..|##.|..#|##.',
  '6': '.##|#..|###|#.#|###', '7': '###|..#|.#.|.#.|.#.', '8': '###|#.#|###|#.#|###',
  '9': '###|#.#|###|..#|##.',
  ' ': '..|..|..|..|..', '.': '.|.|.|.|#', '!': '#|#|#|.|#', '?': '##.|..#|.#.|...|.#.',
  ':': '.|#|.|#|.', '=': '...|###|...|###|...', '-': '...|...|###|...|...', '+': '...|.#.|###|.#.|...',
  '>': '#..|.#.|..#|.#.|#..', ',': '.|.|.|#|#', '/': '..#|..#|.#.|#..|#..', '_': '...|...|...|...|###',
};

export type Rect = { x: number; y: number; w: number; h: number; c: string };

const spriteCache = new Map<string, Rect[]>();
export function spriteRects(rows: string[]): Rect[] {
  const key = rows.join('/');
  const hit = spriteCache.get(key);
  if (hit) return hit;
  const out: Rect[] = [];
  rows.forEach((row, y) => {
    let x = 0;
    while (x < row.length) {
      const ch = row[x];
      if (ch === '.') { x += 1; continue; }
      let e = x + 1;
      while (e < row.length && row[e] === ch) e += 1;
      out.push({ x, y, w: e - x, h: 1, c: PAL[ch] ?? '#FF00FF' });
      x = e;
    }
  });
  spriteCache.set(key, out);
  return out;
}

const textCache = new Map<string, {rects: Rect[]; width: number}>();
export function textLayout(s: string, scale: number, n: number) {
  const key = `${s}|${scale}|${n}`;
  const hit = textCache.get(key);
  if (hit) return hit;
  const rects: Rect[] = [];
  let cx = 0;
  let width = 0;
  for (let i = 0; i < s.length; i += 1) {
    const rows = (FONT[s[i]] ?? FONT['?']).split('|');
    const gw = rows[0].length;
    if (i < n) {
      rows.forEach((row, y) => {
        let x = 0;
        while (x < row.length) {
          if (row[x] !== '#') { x += 1; continue; }
          let e = x + 1;
          while (e < row.length && row[e] === '#') e += 1;
          rects.push({ x: (cx + x) * scale, y: y * scale, w: (e - x) * scale, h: scale, c: '' });
          x = e;
        }
      });
    }
    cx += gw + 1;
    width = cx - 1;
  }
  const out = { rects, width: width * scale };
  textCache.set(key, out);
  return out;
}

// ---- Bit: maskot (12 x 13) ----
const BIT_TOP = ['..CCCCCCCC..', '.CHHCCCCCCD.', 'CHHCCCCCCCCD', 'CHCCCCCCCCCD'];
const EYES = {
  open: ['CCCKKCCKKCCD', 'CCCKWCCKWCCD'],
  blink: ['CCCCCCCCCCCD', 'CCCKKCCKKCCD'],
};
const CHEEK = 'CPPCCCCCCPPD';
const MOUTH = {
  smile: ['CCCCKCCKCCCD', 'CCCCCKKCCCCD'],
  open: ['CCCCKKKKCCCD', 'CCCCKPPKCCCD'],
};
const BIT_BOT = ['CCCCCCCCCCCD', '.CCCCCCCCCD.', '..DDDDDDDD..'];
const FEET = { idle: '.DDD....DDD.', a: 'DDD.....DD..', b: '..DD.....DDD', jump: '..DD....DD..' };

export function bitRows(eyes: 'open' | 'blink', mouth: 'smile' | 'open', feet: 'idle' | 'a' | 'b' | 'jump') {
  return [...BIT_TOP, ...EYES[eyes], CHEEK, ...MOUTH[mouth], ...BIT_BOT, FEET[feet]];
}

export const HEART = ['.PP.PP.', 'PPPPPPP', 'PPPPPPP', '.PPPPP.', '..PPP..', '...P...'];
export const STAR = ['...Y...', '..YYY..', 'YYYYYYY', '.YYYYY.', '..YYY..', '.YY.YY.', '.Y...Y.'];
export const GEAR_A = ['.GGGGG.', 'G..G..G', 'G..G..G', 'GGGGGGG', 'G..G..G', 'G..G..G', '.GGGGG.'];
export const GEAR_B = ['.GGGGG.', 'GG...GG', 'G.G.G.G', 'G..G..G', 'G.G.G.G', 'GG...GG', '.GGGGG.'];
