# Pembuat SFX + musik latar 8-bit untuk video "Bit" (30 detik, 30 fps)
import wave
import numpy as np

SR, FPS, DUR = 44100, 30, 30.0
rng = np.random.default_rng(7)
N = int(SR * (DUR + 1))
sfx = np.zeros(N)
bgm = np.zeros(N)

NOTE = {'F2': 87.31, 'A2': 110.0, 'C3': 130.81, 'F3': 174.61, 'G3': 196.0, 'A3': 220.0,
        'C4': 261.63, 'F4': 349.23, 'G4': 392.0, 'A4': 440.0, 'B4': 493.88, 'C5': 523.25,
        'D5': 587.33, 'E5': 659.25, 'F5': 698.46, 'G5': 783.99, 'A5': 880.0, 'B5': 987.77,
        'C6': 1046.5, 'D6': 1174.66, 'E6': 1318.51, 'G6': 1567.98, 'C7': 2093.0}


def sec(frame):
    return frame / FPS


def tt(dur):
    return np.arange(int(dur * SR)) / SR


def osc(freq, dur, shape='square', duty=0.5):
    n = int(dur * SR)
    f = freq if isinstance(freq, np.ndarray) else np.full(n, float(freq))
    ph = np.cumsum(f) / SR
    if shape == 'square':
        return np.where((ph % 1) < duty, 1.0, -1.0)
    if shape == 'tri':
        return 2 * np.abs(2 * (ph % 1) - 1) - 1
    return np.sin(2 * np.pi * ph)


def env(n, a=0.003, decay=12.0):
    t = np.arange(n) / SR
    return np.minimum(1.0, t / a) * np.exp(-decay * t)


def put(buf, t, sig, gain=1.0):
    i = int(t * SR)
    if i >= len(buf):
        return
    j = min(len(buf), i + len(sig))
    buf[i:j] += sig[: j - i] * gain


def hz(x):
    return NOTE[x] if isinstance(x, str) else x


def blip(note, dur=0.1, shape='square', duty=0.5, decay=14.0):
    s = osc(hz(note), dur, shape, duty)
    return s * env(len(s), decay=decay)


def sweep(f0, f1, dur, shape='sine', decay=6.0, duty=0.5):
    n = int(dur * SR)
    s = osc(np.geomspace(f0, f1, n), dur, shape, duty)
    return s * env(n, decay=decay)


def bell(note, dur=0.55):
    f = hz(note)
    s = osc(f, dur, 'sine') + 0.35 * osc(f * 2.01, dur, 'sine') + 0.12 * osc(f * 3.0, dur, 'sine')
    return s * env(len(s), a=0.002, decay=6.0) * 0.6


def noise(dur, decay=200.0):
    n = int(dur * SR)
    return rng.uniform(-1, 1, n) * env(n, a=0.0005, decay=decay)


def combo(parts, length=1.0):
    out = np.zeros(int(length * SR))
    for off, sig, g in parts:
        put(out, off, sig, g)
    return out


def pop(freq=700):
    return sweep(freq * 1.9, freq * 0.6, 0.09, 'tri', decay=25)


def boing(f0=330, dur=0.32):
    t = tt(dur)
    f = f0 * (0.8 + 0.8 * np.sin(np.pi * t / dur)) + 18 * np.sin(2 * np.pi * 24 * t)
    s = osc(f, dur, 'sine') + 0.3 * osc(f, dur, 'square', 0.25)
    return s * env(len(t), decay=4.5) * 0.7


def thump():
    return sweep(150, 45, 0.14, 'sine', decay=22) * 1.2


def clack(note):
    tick = osc(hz(note), 0.04, 'sine') * env(int(0.04 * SR), decay=70)
    return combo([(0, noise(0.02, 300), 0.5), (0, tick, 0.6)], 0.06)


def step(alt):
    n = int(0.03 * SR)
    return combo([(0, noise(0.025, 220), 0.4), (0, osc(180 if alt else 240, 0.03, 'sine') * env(n, decay=120), 0.5)], 0.04)


def sparkle(base=('C6', 'E6', 'G6')):
    return combo([(i * 0.05, bell(b, 0.3), 0.7) for i, b in enumerate(base)], 0.5)


def fanfare():
    parts = [(i * 0.07, blip(n, 0.12, 'square', 0.25, 10), 0.5) for i, n in enumerate(['C5', 'E5', 'G5', 'C6'])]
    for n in ['C5', 'E5', 'G5', 'C6']:
        parts.append((0.3, blip(n, 0.6, 'tri', decay=4), 0.45))
        parts.append((0.3, blip(n, 0.6, 'square', 0.25, 5), 0.18))
    return combo(parts, 1.0)


def yay():
    return combo([(0, blip('E5', 0.12, 'square', 0.5, 8), 0.5), (0.11, blip('A5', 0.22, 'square', 0.5, 6), 0.5),
                  (0.11, sweep(880, 1320, 0.2, 'sine', 8), 0.3)], 0.5)


SCENE = {0: 0, 1: 105, 2: 300, 3: 465, 4: 645, 5: 780, 6: 830}
LOG = []


def at(scene, local):
    return sec(SCENE[scene] + local)


def S(scene, local, sig, gain=0.6, name=''):
    t = at(scene, local)
    put(sfx, t, sig, gain)
    LOG.append((round(t, 2), SCENE[scene] + local, name))


# ---------- langkah kaki saat Bit berjalan ----------
WALK = [(0, 85, 105), (1, 0, 35), (2, 0, 28), (2, 128, 165), (3, 0, 22), (3, 160, 180), (4, 0, 20), (4, 115, 135), (5, 0, 18)]
for sc, a, b in WALK:
    for f in range(a, b):
        if f % 5 == 0:
            put(sfx, at(sc, f), step((f // 5) % 2), 0.45)

# ---------- adegan 0: judul ----------
S(0, 2, sweep(1500, 420, 0.4, 'sine', 3), 0.3, 'jatuh')
S(0, 22, thump(), 0.55, 'mendarat')
S(0, 22, boing(300), 0.5, 'boing mendarat')
S(0, 38, boing(420, 0.2), 0.3, 'boing kecil')
for i, n in enumerate(['C5', 'D5', 'E5', 'G5', 'A5', 'C6', 'D6', 'E6']):
    S(0, 28 + 4 * i, blip(n, 0.08, 'tri', decay=18), 0.3, 'huruf judul')
S(0, 44, blip('E5', 0.09, 'square', 0.5, 12), 0.4, 'ha')
S(0, 48, blip('G5', 0.14, 'square', 0.5, 9), 0.4, 'lo')
S(0, 62, sparkle(), 0.5, 'subjudul')

# ---------- adegan 1: representasi ----------
S(1, 38, pop(800), 0.6, 'tile A')
S(1, 38, bell('E6', 0.3), 0.35, 'tile A bel')
S(1, 48, blip('G5', 0.05, 'square', 0.5, 40), 0.3, 'tanda sama')
S(1, 54, pop(900), 0.6, 'tile 65')
S(1, 64, blip('G5', 0.05, 'square', 0.5, 40), 0.3, 'tanda sama')
for i, n in enumerate(['C5', 'D5', 'E5', 'G5', 'A5', 'C6', 'D6', 'E6']):
    S(1, 72 + 7 * i, blip(n, 0.12, 'square', 0.5, 11), 0.42, f'bit {i + 1}')
S(1, 128, sparkle(('G5', 'C6', 'E6')), 0.5, 'semua bit')
S(1, 130, sparkle(), 0.3, 'keterangan')
S(1, 135, boing(380, 0.25), 0.35, 'lompat')
S(1, 160, boing(380, 0.25), 0.35, 'lompat')

# ---------- adegan 2: input ----------
S(2, 30, pop(650), 0.5, 'panel')
for fr, n in zip([45, 55, 65, 75], ['C5', 'E5', 'G5', 'E5']):
    S(2, fr, clack(n), 0.7, 'ketik')
S(2, 86, clack('C4'), 0.6, 'klik mouse')
S(2, 88, bell('G5', 0.3), 0.45, 'enter 1')
S(2, 91, bell('C6', 0.5), 0.5, 'enter 2')
S(2, 96, sparkle(), 0.4, 'keterangan')
S(2, 100, boing(380, 0.25), 0.35, 'lompat')
S(2, 118, boing(420, 0.25), 0.35, 'lompat')

# ---------- adegan 3: proses ----------
for i in range(4):
    S(3, 14 + 9 * i + 27, blip('G3', 0.09, 'square', 0.25, 20), 0.5, 'nyam')
for fr, n in zip([44, 64, 84, 104], ['E5', 'G5', 'A5', 'C6']):
    S(3, fr, blip(n, 0.12, 'square', 0.5, 10), 0.42, 'ganti operasi')
steps_c = ['C5', 'E5', 'G5', 'A5', 'G5', 'E5', 'D5', 'C5', 'E5', 'A5', 'G5', 'C6', 'A5', 'G5', 'E5', 'D5']
for k in range(27):
    fr = 41 + 3 * k
    n = steps_c[k % len(steps_c)]
    S(3, fr, blip(n, 0.07, 'square', 0.25, 22), 0.16, 'komputasi')
for fr, n in zip([108, 116, 124, 132], ['A5', 'G5', 'E5', 'C5']):
    S(3, fr, pop(hz(n) * 0.8), 0.5, 'keluar')
for fr, n in zip([140, 146, 152, 158], ['C5', 'E5', 'G5', 'C6']):
    S(3, fr, bell(n, 0.45), 0.5, 'cek urut')
S(3, 142, boing(400, 0.25), 0.3, 'lompat')
S(3, 145, sparkle(), 0.3, 'keterangan')
S(3, 158, boing(400, 0.25), 0.3, 'lompat')

# ---------- adegan 4: output ----------
S(4, 20, sweep(220, 1400, 0.25, 'tri', 3), 0.4, 'layar nyala')
for fr, n in zip([34, 44, 54, 64], ['C5', 'E5', 'G5', 'C6']):
    S(4, fr, sweep(hz(n) * 0.7, hz(n), 0.22, 'square', 9, 0.25), 0.4, 'batang naik')
S(4, 78, fanfare(), 0.8, 'ta-da')
S(4, 80, boing(400, 0.25), 0.3, 'lompat')
for k, fr in enumerate(range(88, 110, 4)):
    S(4, fr, combo([(0, osc(95, 0.05, 'square', 0.5) * env(int(0.05 * SR), decay=30), 0.5), (0, noise(0.05, 60), 0.25)], 0.06), 0.4, 'printer')
S(4, 92, sparkle(), 0.3, 'keterangan')
S(4, 100, boing(420, 0.25), 0.3, 'lompat')

# ---------- adegan 5: simpan ----------
S(5, 22, boing(400, 0.25), 0.35, 'lompat')
S(5, 22, sweep(500, 1800, 0.4, 'sine', 5), 0.3, 'bintang terbang')
S(5, 34, combo([(0, clack('C4'), 0.8), (0.03, bell('B5', 0.25), 0.6), (0.09, bell('E6', 0.5), 0.6)], 0.7), 0.7, 'simpan')
for i, n in enumerate(['E5', 'G5', 'C6']):
    S(5, 38 + 3 * i, blip(n, 0.1, 'square', 0.5, 9), 0.4, 'tersimpan')
S(5, 42, sparkle(), 0.3, 'keterangan')

# ---------- adegan 6: penutup ----------
for i, n in enumerate(['C5', 'E5', 'G5', 'C6', 'E6', 'G6']):
    S(6, 4 + 3 * i, blip(n, 0.15, 'square', 0.25, 7), 0.45, 'arpeggio')
S(6, 22, yay(), 0.6, 'yay')
for i in range(4):
    S(6, 20 + 6 * i, pop(900 + 100 * i), 0.3, 'hati')
for fr in (10, 26, 42):
    S(6, fr, boing(400, 0.25), 0.3, 'lompat')
S(6, 60, bell('C6', 1.0), 0.7, 'lonceng akhir')
S(6, 60, bell('G5', 1.0), 0.4, 'lonceng akhir')

# ---------- transisi piksel ----------
for c in (105, 300, 465, 645, 780, 830):
    put(sfx, sec(c - 9), sweep(1300, 300, 0.15, 'square', 7, 0.25), 0.22)
    put(sfx, sec(c), sweep(300, 1300, 0.15, 'square', 7, 0.25), 0.22)

# ---------- musik latar (C mayor, 120 bpm) ----------
E8 = 0.25
MEL = [
    'C5 E5 G5 E5 C5 E5 G5 E5', 'A4 C5 E5 C5 A4 C5 E5 C5', 'F4 A4 C5 A4 F4 A4 C5 A4', 'G4 B4 D5 B4 G4 B4 D5 B4',
    'E5 E5 G5 G5 A5 A5 G5 -', 'E5 E5 D5 D5 C5 C5 D5 -', 'F5 F5 E5 E5 D5 D5 E5 -', 'D5 D5 B4 B4 G4 G4 C5 C5',
]
BASS = ['C3', 'A2', 'F3', 'G3', 'C3', 'A2', 'F3', 'G3']
bar_len = 8 * E8
total_bars = int(DUR / bar_len) + 1
for b in range(total_bars):
    mel = MEL[b % 8].split()
    for i, n in enumerate(mel):
        t = b * bar_len + i * E8
        if n != '-' and t < DUR:
            put(bgm, t, blip(n, 0.2, 'square', 0.25, 6), 0.10)
    for q in range(4):
        t = b * bar_len + q * 0.5
        put(bgm, t, blip(BASS[b % 8], 0.3, 'tri', decay=5), 0.28)
        if q in (0, 2):
            put(bgm, t, sweep(140, 45, 0.12, 'sine', 22), 0.30)
        else:
            put(bgm, t, noise(0.07, 45), 0.07)
    for i in range(8):
        put(bgm, b * bar_len + i * E8 + 0.125, noise(0.02, 300), 0.05)

fade = np.ones(N)
fi, fo = int(0.3 * SR), int(1.8 * SR)
fade[:fi] = np.linspace(0, 1, fi)
end = int(DUR * SR)
fade[end - fo:end] = np.linspace(1, 0, fo)
bgm *= fade

mix = sfx + bgm * 0.55
mix = mix[:end]
tail = int(0.25 * SR)
mix[-tail:] *= np.linspace(1, 0, tail)
mix = mix / np.max(np.abs(mix)) * 0.9

with wave.open('bit-sfx.wav', 'wb') as w:
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes((mix * 32767).astype('<i2').tobytes())

print('selesai: bit-sfx.wav,', round(len(mix) / SR, 2), 'detik,', len(LOG), 'efek terjadwal')
